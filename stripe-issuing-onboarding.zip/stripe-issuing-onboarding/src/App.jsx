import React, { useState, useRef, useCallback } from 'react'
import CardVisual from './CardVisual.jsx'
import {
  USE_CASE_MAP, AUDIENCE_NAMES, CARD_TYPE_NAMES, CURRENCY_NAMES,
  PROGRAM_NAMES, OUTCOME_MATRIX, MOCK_STRIPE_ACCOUNT, STEPS
} from './data.js'

// ─── Shared UI primitives ───────────────────────────────────────────────────

const btn = {
  primary: { width: '100%', maxWidth: 520, height: 44, background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'inherit' },
  submit: { width: '100%', maxWidth: 520, height: 48, background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, fontSize: 15, fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'inherit' },
  secondary: { width: '100%', maxWidth: 520, height: 44, background: '#fff', color: '#111827', border: '0.5px solid #e5e7eb', borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'inherit' },
  amber: { background: '#d97706', color: '#fff' },
}

function BackLink({ onClick }) {
  return (
    <div onClick={onClick} style={{ fontSize: 12, color: '#6b7280', cursor: 'pointer', marginTop: 12, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
      <i className="ti ti-arrow-left" style={{ fontSize: 12 }} /> Back
    </div>
  )
}

function OptionCard({ selected, onClick, children }) {
  return (
    <div onClick={onClick} style={{
      border: selected ? '2px solid #4f46e5' : '0.5px solid #e5e7eb',
      background: selected ? '#eeedfe' : '#fff',
      borderRadius: 12, padding: '14px 18px', marginBottom: 10, cursor: 'pointer',
      transition: 'border-color 0.15s, background 0.1s',
    }}>
      {children}
    </div>
  )
}

function OptTitle({ selected, children }) {
  return <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 4, color: selected ? '#4f46e5' : '#111827' }}>{children}</div>
}

function OptDesc({ selected, children }) {
  return <div style={{ fontSize: 12, color: selected ? '#534ab7' : '#6b7280' }}>{children}</div>
}

function Bullet({ children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#6b7280', marginTop: 4 }}>
      <i className="ti ti-check" style={{ fontSize: 12, color: '#a5b4fc' }} />
      {children}
    </div>
  )
}

function BulletSelected({ children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#534ab7', marginTop: 4 }}>
      <i className="ti ti-check" style={{ fontSize: 12, color: '#4f46e5' }} />
      {children}
    </div>
  )
}

function ProgBadge({ type, children }) {
  const colors = {
    stripe: { bg: '#eeedfe', color: '#4f46e5' },
    cobrand: { bg: '#e1f5ee', color: '#0f6e56' },
    custom: { bg: '#faeeda', color: '#854f0b' },
  }
  const c = colors[type]
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11, padding: '3px 8px', borderRadius: 20, marginBottom: 8, fontWeight: 500, background: c.bg, color: c.color }}>
      {children}
    </div>
  )
}

function SectionTitle({ children }) {
  return <div style={{ fontSize: 22, fontWeight: 500, marginBottom: 6, lineHeight: 1.3 }}>{children}</div>
}

function SectionSub({ children }) {
  return <div style={{ fontSize: 14, color: '#6b7280', marginBottom: 24 }}>{children}</div>
}

function SidebarCard({ title, body, link }) {
  return (
    <div style={{ background: '#fff', border: '0.5px solid #f3f4f6', borderRadius: 12, padding: 16, marginBottom: 12 }}>
      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6 }}>{title}</div>
      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 10, lineHeight: 1.6 }}>{body}</div>
      {link && <div style={{ fontSize: 12, color: '#4f46e5', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 3 }}>{link} <i className="ti ti-external-link" style={{ fontSize: 11 }} /></div>}
    </div>
  )
}

function LoadingDots() {
  return (
    <div style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
      {[0, 0.2, 0.4].map((d, i) => (
        <span key={i} style={{ width: 5, height: 5, borderRadius: '50%', background: '#9ca3af', display: 'block', animation: `dot-bounce 1.2s infinite ease-in-out ${d}s` }} />
      ))}
    </div>
  )
}

// ─── Stepper ────────────────────────────────────────────────────────────────

function Stepper({ current, total, labels }) {
  return (
    <div style={{ padding: '24px 20px', borderRight: '0.5px solid #f3f4f6', background: '#fff', display: 'flex', flexDirection: 'column' }}>
      {labels.map((label, i) => (
        <React.Fragment key={i}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 20 }}>
            <div style={{
              width: 22, height: 22, borderRadius: '50%', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, marginTop: 1,
              background: i < current ? '#4f46e5' : 'transparent',
              color: i < current ? '#fff' : 'transparent',
              border: i < current ? 'none' : i === current ? '2px solid #4f46e5' : '1.5px dashed #e5e7eb',
            }}>
              {i < current ? <i className="ti ti-check" style={{ fontSize: 10 }} /> : i === current ? <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#4f46e5' }} /> : null}
            </div>
            <div style={{ fontSize: 13, color: i < current ? '#111827' : i === current ? '#4f46e5' : '#6b7280', fontWeight: i === current ? 500 : 400, paddingTop: 2 }}>{label}</div>
          </div>
          {i < labels.length - 1 && (
            <div style={{ width: 2, height: 14, background: i < current ? '#4f46e5' : '#f3f4f6', marginLeft: 10, marginTop: -14, marginBottom: 6 }} />
          )}
        </React.Fragment>
      ))}
    </div>
  )
}

// ─── Individual Steps ────────────────────────────────────────────────────────

function StepWelcome({ onNext }) {
  return (
    <div>
      <div style={{ background: 'linear-gradient(135deg,#4f46e5 0%,#7c3aed 50%,#06b6d4 100%)', borderRadius: 12, padding: 24, marginBottom: 28, position: 'relative', overflow: 'hidden' }}>
        <div style={{ fontSize: 11, background: 'rgba(255,255,255,0.2)', color: '#fff', padding: '3px 10px', borderRadius: 20, display: 'inline-block', marginBottom: 12 }}>Stripe Issuing</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 20, fontWeight: 500, color: '#fff', lineHeight: 1.3, marginBottom: 8 }}>Get started with<br />Stripe Issuing</div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', marginBottom: 16 }}>Launch your card program in minutes.</div>
            <button onClick={onNext} style={{ background: '#fff', color: '#4f46e5', border: 'none', borderRadius: 8, padding: '10px 24px', fontSize: 13, fontWeight: 500, cursor: 'pointer', fontFamily: 'inherit' }}>Get started →</button>
          </div>
          <div style={{ width: 100, height: 62, background: 'rgba(255,255,255,0.15)', borderRadius: 8, border: '0.5px solid rgba(255,255,255,0.3)', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', padding: 8, position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)' }}>
            <div style={{ width: 16, height: 12, background: 'rgba(255,255,255,0.6)', borderRadius: 2, marginBottom: 6 }} />
            <div style={{ fontSize: 7, color: 'rgba(255,255,255,0.8)', letterSpacing: 1 }}>•••• •••• 4242</div>
          </div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
        {[
          { icon: 'ti-credit-card', title: 'Virtual & physical cards', sub: 'Issue cards for your team in a few clicks' },
          { icon: 'ti-currency-dollar', title: 'Multi-currency spend', sub: 'Spend from your financial account balance' },
          { icon: 'ti-receipt', title: 'Expense management', sub: 'Manage subscriptions, bills, and expenses' },
          { icon: 'ti-shield-lock', title: 'Spend controls', sub: 'Set limits and track usage per card' },
        ].map((f, i) => (
          <div key={i} style={{ background: '#f7f7f8', borderRadius: 8, padding: 12, display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <div style={{ width: 28, height: 28, borderRadius: 6, background: '#eeedfe', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <i className={`ti ${f.icon}`} style={{ fontSize: 14, color: '#4f46e5' }} />
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 2 }}>{f.title}</div>
              <div style={{ fontSize: 11, color: '#6b7280' }}>{f.sub}</div>
            </div>
          </div>
        ))}
      </div>
      <button onClick={onNext} style={btn.primary}>Continue</button>
    </div>
  )
}

function StepCardType({ value, onChange, onNext, onBack }) {
  const opts = [
    { val: 'prefunded', title: 'Prefunded card', desc: 'Cards funded directly from your balance. Spend what you have.' },
    { val: 'charge', title: 'Charge', desc: 'Cards with no preset spending limit. Full balance due each cycle.' },
    { val: 'credit', title: 'Credit', desc: 'Revolving credit cards with a set credit limit.' },
  ]
  return (
    <div>
      <SectionTitle>What type of card are you looking for?</SectionTitle>
      <SectionSub>Choose the card type that fits your program.</SectionSub>
      {opts.map(o => (
        <OptionCard key={o.val} selected={value === o.val} onClick={() => onChange(o.val)}>
          <OptTitle selected={value === o.val}>{o.title}</OptTitle>
          <OptDesc selected={value === o.val}>{o.desc}</OptDesc>
        </OptionCard>
      ))}
      <div style={{ marginTop: 28 }}>
        <button onClick={onNext} disabled={!value} style={{ ...btn.primary, opacity: value ? 1 : 0.4, cursor: value ? 'pointer' : 'not-allowed' }}>Continue</button>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepCurrency({ value, onChange, onNext, onBack }) {
  return (
    <div>
      <SectionTitle>What currency do you want your cards backed by?</SectionTitle>
      <SectionSub>Select the settlement currency for your card program.</SectionSub>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        {[{ val: 'local', icon: 'ti-world', title: 'Local currency', desc: "Settle in your business's home currency" }, { val: 'usdc', icon: 'ti-coins', title: 'USDC', desc: 'Settle in USD Coin stablecoin' }].map(o => (
          <div key={o.val} onClick={() => onChange(o.val)} style={{ border: value === o.val ? '2px solid #4f46e5' : '0.5px solid #e5e7eb', background: value === o.val ? '#eeedfe' : '#fff', borderRadius: 12, padding: 16, cursor: 'pointer', transition: 'border-color 0.15s' }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: value === o.val ? '#fff' : '#eeedfe', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
              <i className={`ti ${o.icon}`} style={{ fontSize: 16, color: '#4f46e5' }} />
            </div>
            <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 3, color: value === o.val ? '#4f46e5' : '#111827' }}>{o.title}</div>
            <div style={{ fontSize: 11, color: '#6b7280' }}>{o.desc}</div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 28 }}>
        <button onClick={onNext} disabled={!value} style={{ ...btn.primary, opacity: value ? 1 : 0.4, cursor: value ? 'pointer' : 'not-allowed' }}>Continue</button>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepCardholder({ value, onChange, onNext, onBack }) {
  const opts = [
    { val: 'company', title: 'My company', desc: 'Issue cards for employees, contractors, or internal teams.' },
    { val: 'businesses', title: 'Businesses on my platform', desc: 'Issue cards to business customers that use your platform.' },
    { val: 'consumers', title: 'Consumers on my platform', desc: 'Issue cards to individual end users of your product.' },
  ]
  return (
    <div>
      <SectionTitle>Who are the cards for?</SectionTitle>
      <SectionSub>This helps us configure the right card program structure.</SectionSub>
      {opts.map(o => (
        <OptionCard key={o.val} selected={value === o.val} onClick={() => onChange(o.val)}>
          <OptTitle selected={value === o.val}>{o.title}</OptTitle>
          <OptDesc selected={value === o.val}>{o.desc}</OptDesc>
        </OptionCard>
      ))}
      <div style={{ marginTop: 28 }}>
        <button onClick={onNext} disabled={!value} style={{ ...btn.primary, opacity: value ? 1 : 0.4, cursor: value ? 'pointer' : 'not-allowed' }}>Continue</button>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepUseCase({ audience, usecase, onUsecase, desc, onDesc, onNext, onBack }) {
  const [evaluating, setEvaluating] = useState(false)
  const debounceRef = useRef(null)

  const cases = USE_CASE_MAP[audience] || []

  const silentEval = useCallback(async (text) => {
    if (!usecase || text.length < 30) return
    setEvaluating(true)
    try {
      const ul = cases.find(c => c.val === usecase)?.title || usecase
      await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 300,
          system: 'Stripe Issuing risk evaluator. Respond ONLY with JSON: {"status":"supported"|"needs_info"|"unsupported","flags":["brief note"]}. No markdown.',
          messages: [{ role: 'user', content: `Use case: ${ul}\nCardholder: ${AUDIENCE_NAMES[audience]}\nDescription: ${text}` }]
        })
      })
    } catch (_) {}
    setEvaluating(false)
  }, [usecase, audience, cases])

  const handleDesc = (e) => {
    onDesc(e.target.value)
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => silentEval(e.target.value), 2000)
  }

  const canContinue = !!usecase || desc.length > 0

  return (
    <div>
      <SectionTitle>What's your use case?</SectionTitle>
      <SectionSub>Select a use case and describe your program.</SectionSub>
      {audience && (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, background: '#f7f7f8', border: '0.5px solid #f3f4f6', borderRadius: 20, padding: '3px 10px', marginBottom: 16, color: '#6b7280' }}>
          <i className="ti ti-user" style={{ fontSize: 11 }} /> Cards for: <strong style={{ color: '#111827' }}>{AUDIENCE_NAMES[audience]}</strong>
        </div>
      )}
      {cases.map(c => (
        <OptionCard key={c.val} selected={usecase === c.val} onClick={() => onUsecase(c.val)}>
          <OptTitle selected={usecase === c.val}>{c.title}</OptTitle>
          <OptDesc selected={usecase === c.val}>{c.desc}</OptDesc>
        </OptionCard>
      ))}
      <div style={{ marginTop: 24, paddingTop: 24, borderTop: '0.5px solid #f3f4f6', maxWidth: 520 }}>
        <label style={{ fontSize: 13, fontWeight: 500, marginBottom: 4, display: 'block' }}>Describe the program you're trying to launch</label>
        <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 10 }}>Tell us about your business, who will use the cards, expected monthly spend, and any specific requirements.</div>
        <textarea value={desc} onChange={handleDesc} rows={4}
          placeholder="e.g. We're an insurance company wanting to issue virtual debit cards to policyholders for approved claims instantly…"
          style={{ width: '100%', minHeight: 90, border: '0.5px solid #e5e7eb', borderRadius: 8, padding: '10px 12px', fontSize: 13, fontFamily: 'inherit', color: '#111827', background: '#fff', resize: 'vertical', outline: 'none' }}
        />
        {evaluating && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#6b7280', marginTop: 10 }}>
            <LoadingDots /> Reviewing your program details…
          </div>
        )}
      </div>
      <div style={{ marginTop: 28 }}>
        <button onClick={onNext} disabled={!canContinue} style={{ ...btn.primary, opacity: canContinue ? 1 : 0.4, cursor: canContinue ? 'pointer' : 'not-allowed' }}>Continue</button>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepCardProgram({ value, onChange, onNext, onBack }) {
  return (
    <div>
      <SectionTitle>What kind of card program are you interested in?</SectionTitle>
      <SectionSub>Choose the program that best fits your needs.</SectionSub>

      <OptionCard selected={value === 'stripe-branded'} onClick={() => onChange('stripe-branded')}>
        <ProgBadge type="stripe"><i className="ti ti-bolt" style={{ fontSize: 11 }} /> Stripe branded</ProgBadge>
        <OptTitle selected={value === 'stripe-branded'}>Stripe branded cards</OptTitle>
        {value === 'stripe-branded' ? <><BulletSelected>No-code solution</BulletSelected><BulletSelected>Free card issuance</BulletSelected></> : <><Bullet>No-code solution</Bullet><Bullet>Free card issuance</Bullet></>}
      </OptionCard>

      <OptionCard selected={value === 'co-branded'} onClick={() => onChange('co-branded')}>
        <ProgBadge type="cobrand"><i className="ti ti-medal" style={{ fontSize: 11 }} /> Co-branded</ProgBadge>
        <OptTitle selected={value === 'co-branded'}>Co-branded cards</OptTitle>
        {value === 'co-branded'
          ? <><BulletSelected>Access to Issuing APIs</BulletSelected><BulletSelected>Rev share based on spend volume</BulletSelected><BulletSelected>Pay as you go / activity-based pricing</BulletSelected></>
          : <><Bullet>Access to Issuing APIs</Bullet><Bullet>Rev share based on spend volume</Bullet><Bullet>Pay as you go / activity-based pricing</Bullet></>}
      </OptionCard>

      <OptionCard selected={value === 'custom'} onClick={() => onChange('custom')}>
        <ProgBadge type="custom"><i className="ti ti-adjustments" style={{ fontSize: 11 }} /> Custom</ProgBadge>
        <OptTitle selected={value === 'custom'}>Custom solution</OptTitle>
        {value === 'custom'
          ? <><BulletSelected>Opportunity for custom branded cards</BulletSelected><BulletSelected>Access to Issuing APIs</BulletSelected><BulletSelected>Rev share + custom commercial terms</BulletSelected><BulletSelected>And more…</BulletSelected></>
          : <><Bullet>Opportunity for custom branded cards</Bullet><Bullet>Access to Issuing APIs</Bullet><Bullet>Rev share + custom commercial terms</Bullet><Bullet>And more…</Bullet></>}
      </OptionCard>

      <div style={{ marginTop: 28 }}>
        <button onClick={onNext} disabled={!value} style={{ ...btn.primary, opacity: value ? 1 : 0.4, cursor: value ? 'pointer' : 'not-allowed' }}>Continue</button>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepYourCard({ outcome, bizName, onNext, onBack }) {
  if (!outcome) return null
  const acConfig = {
    production: { cls: 'production', label: 'Instant production access', icon: 'ti-rocket', bg: '#eaf3de', color: '#3b6d11', border: '#c3dfa3' },
    trial: { cls: 'trial', label: 'Instant live mode trial', icon: 'ti-flask', bg: '#e0f2fe', color: '#075985', border: '#bae6fd' },
    sales: { cls: 'sales', label: 'Sales will be in touch', icon: 'ti-headset', bg: '#fef3c7', color: '#92400e', border: '#fcd34d' },
  }
  const ac = acConfig[outcome.type]

  return (
    <div style={{ maxWidth: 520 }}>
      <SectionTitle>{outcome.headline}</SectionTitle>
      <SectionSub>{outcome.sub}</SectionSub>
      <CardVisual cardClass={outcome.cardClass} cardName={outcome.cardName} bizName={bizName} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 500, padding: '6px 14px', borderRadius: 20, margin: '0 auto 24px', width: 'fit-content', background: ac.bg, color: ac.color, border: `0.5px solid ${ac.border}` }}>
        <i className={`ti ${ac.icon}`} style={{ fontSize: 12 }} /> {ac.label}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 8 }}>
        {outcome.perks.map((p, i) => (
          <div key={i} style={{ background: '#f7f7f8', borderRadius: 8, padding: 12, display: 'flex', alignItems: 'flex-start', gap: 8 }}>
            <div style={{ width: 24, height: 24, borderRadius: 5, background: '#eeedfe', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <i className={`ti ${p.icon}`} style={{ fontSize: 12, color: '#4f46e5' }} />
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 1 }}>{p.t}</div>
              <div style={{ fontSize: 11, color: '#6b7280' }}>{p.d}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 28 }}>
        <button onClick={onNext} style={btn.primary}>Continue <i className="ti ti-arrow-right" style={{ fontSize: 13 }} /></button>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepKYB({ fields, onChange, prefilled, onPrefill, onClearPrefill, prefilling, onNext, onBack }) {
  const allFilled = Object.values(fields).every(v => v.trim().length > 0)
  const fieldDefs = [
    { id: 'bizname', label: 'Legal business name', placeholder: 'Galtee Insurance Ltd.', full: true },
    { id: 'regno', label: 'Registration number', placeholder: '12345678' },
    { id: 'country', label: 'Country of incorporation', placeholder: 'United States' },
    { id: 'address', label: 'Registered address', placeholder: '123 Main St, New York, NY 10001', full: true },
    { id: 'biztype', label: 'Business type', placeholder: 'e.g. LLC, Corporation' },
    { id: 'ein', label: 'Tax ID (EIN)', placeholder: 'XX-XXXXXXX' },
  ]
  const ownerDefs = [
    { id: 'fname', label: 'First name', placeholder: 'Jane' },
    { id: 'lname', label: 'Last name', placeholder: 'Smith' },
    { id: 'dob', label: 'Date of birth', placeholder: 'MM / DD / YYYY' },
    { id: 'pct', label: 'Ownership %', placeholder: 'e.g. 25%' },
    { id: 'title', label: 'Title / Role', placeholder: 'e.g. CEO, Director', full: true },
  ]

  const renderFields = (defs) => (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
      {defs.map(f => (
        <div key={f.id} style={{ display: 'flex', flexDirection: 'column', gap: 5, gridColumn: f.full ? '1/-1' : 'auto' }}>
          <label style={{ fontSize: 12, fontWeight: 500, color: '#111827' }}>{f.label}</label>
          <input value={fields[f.id] || ''} onChange={e => onChange(f.id, e.target.value)}
            placeholder={f.placeholder}
            style={{ border: `0.5px solid ${prefilled && fields[f.id] ? '#c7c2f5' : '#e5e7eb'}`, borderRadius: 8, padding: '9px 12px', fontSize: 13, fontFamily: 'inherit', color: '#111827', background: prefilled && fields[f.id] ? '#f5f4ff' : '#fff', outline: 'none', width: '100%' }} />
        </div>
      ))}
    </div>
  )

  return (
    <div>
      <SectionTitle>Business verification</SectionTitle>
      <SectionSub>We're required to verify your business before activating Issuing.</SectionSub>

      {!prefilled && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '14px 16px', background: '#eeedfe', border: '1px solid #c7c2f5', borderRadius: 12, marginBottom: 24, maxWidth: 560 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: '#4f46e5', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <i className="ti ti-building-bank" style={{ color: '#fff', fontSize: 15 }} />
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500, color: '#312e81', marginBottom: 2 }}>Prefill from your Stripe account</div>
              <div style={{ fontSize: 12, color: '#4f46e5' }}>We already have your business info on file — use it to skip this form.</div>
            </div>
          </div>
          <button onClick={onPrefill} disabled={prefilling} style={{ flexShrink: 0, background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, padding: '8px 16px', fontSize: 12, fontWeight: 500, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, fontFamily: 'inherit' }}>
            {prefilling ? <LoadingDots /> : <><i className="ti ti-download" style={{ fontSize: 12 }} /> Prefill</>}
          </button>
        </div>
      )}

      {prefilled && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', background: '#eaf3de', border: '0.5px solid #c3dfa3', borderRadius: 8, marginBottom: 16, maxWidth: 560, fontSize: 12, color: '#3b6d11' }}>
          <i className="ti ti-circle-check" style={{ fontSize: 14 }} />
          <span>Business information prefilled from your Stripe account. Review and confirm below.</span>
          <span onClick={onClearPrefill} style={{ fontSize: 12, color: '#4f46e5', cursor: 'pointer', marginLeft: 'auto' }}>Clear & enter manually</span>
        </div>
      )}

      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 14, paddingBottom: 8, borderBottom: '0.5px solid #f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          Business information
          {prefilled && <span style={{ fontSize: 11, background: '#eeedfe', color: '#4f46e5', padding: '2px 8px', borderRadius: 20 }}><i className="ti ti-circle-check" style={{ fontSize: 10 }} /> Prefilled</span>}
        </div>
        {renderFields(fieldDefs)}
      </div>

      <div>
        <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 14, paddingBottom: 8, borderBottom: '0.5px solid #f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          Beneficial owner
          {prefilled && <span style={{ fontSize: 11, background: '#eeedfe', color: '#4f46e5', padding: '2px 8px', borderRadius: 20 }}><i className="ti ti-circle-check" style={{ fontSize: 10 }} /> Prefilled</span>}
        </div>
        {renderFields(ownerDefs)}
      </div>

      <div style={{ marginTop: 28 }}>
        <button onClick={onNext} disabled={!allFilled} style={{ ...btn.primary, opacity: allFilled ? 1 : 0.4, cursor: allFilled ? 'pointer' : 'not-allowed' }}>Continue</button>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepReview({ selections, outcome, prefilled, onSubmit, onBack }) {
  const ul = selections.usecase ? (USE_CASE_MAP[selections.audience] || []).find(c => c.val === selections.usecase)?.title || selections.usecase : '—'
  const desc = selections.desc || ''
  const rows = [
    ['Card type', CARD_TYPE_NAMES[selections.cardtype] || '—'],
    ['Currency', CURRENCY_NAMES[selections.currency] || '—'],
    ['Cardholder', AUDIENCE_NAMES[selections.audience] || '—'],
    ['Use case', ul],
    ['Program description', desc || '—'],
    ['Card program', PROGRAM_NAMES[selections.cardprogram] || '—'],
    ['Your card', outcome ? outcome.cardName : '—'],
    ['Business verification', prefilled ? 'Prefilled from Stripe account' : 'Manually entered'],
  ]
  return (
    <div>
      <SectionTitle>Review & submit</SectionTitle>
      <SectionSub>Check your selections before submitting your application.</SectionSub>
      <div style={{ background: '#f7f7f8', borderRadius: 12, padding: 16, marginBottom: 12 }}>
        {rows.map(([label, val], i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '7px 0', borderBottom: i < rows.length - 1 ? '0.5px solid #f3f4f6' : 'none', fontSize: 13 }}>
            <span style={{ color: '#6b7280' }}>{label}</span>
            <span style={{ fontWeight: 500, textAlign: 'right', maxWidth: 260 }}>{val.length > 60 ? val.slice(0, 57) + '…' : val}</span>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 28 }}>
        <button onClick={onSubmit} style={btn.submit}><i className="ti ti-send" /> Submit application</button>
        <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 10, maxWidth: 520, lineHeight: 1.6 }}>By submitting, you agree to Stripe's Issuing terms of service and confirm that the information provided is accurate.</div>
        <BackLink onClick={onBack} />
      </div>
    </div>
  )
}

function StepCongrats({ outcome }) {
  if (!outcome) return null
  const isSales = outcome.type === 'sales'
  const isTrial = outcome.type === 'trial'
  const emoji = isSales ? '🤝' : isTrial ? '🧪' : '🎉'
  const title = isSales ? 'Application received!' : isTrial ? 'Trial is live!' : "You're all set!"
  const sub = isSales
    ? `Your application for the ${outcome.cardName} has been received. Our sales team will reach out within 1 business day to finalise your custom arrangement.`
    : isTrial
    ? `Your ${outcome.cardName} live mode trial is active. Start transacting immediately while our team finalises your commercial terms.`
    : `Your ${outcome.cardName} program is live and ready to go. Head to the dashboard to issue your first card.`

  return (
    <div style={{ maxWidth: 520, textAlign: 'center', padding: '20px 0 40px' }}>
      <div style={{ fontSize: 48, marginBottom: 20, animation: 'pop 0.5s ease-out' }}>{emoji}</div>
      <div style={{ fontSize: 26, fontWeight: 600, marginBottom: 10 }}>{title}</div>
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: '#eeedfe', color: '#4f46e5', fontSize: 13, fontWeight: 600, padding: '6px 16px', borderRadius: 20, marginBottom: 28, border: '0.5px solid #c7c2f5' }}>
        <i className="ti ti-credit-card" style={{ fontSize: 13 }} /> {outcome.cardName}
      </div>
      <p style={{ fontSize: 14, color: '#6b7280', marginBottom: 28, lineHeight: 1.7, maxWidth: 400, margin: '0 auto 28px' }}>{sub}</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 380, margin: '0 auto 28px', textAlign: 'left' }}>
        {outcome.nextSteps.map((step, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', background: '#f7f7f8', borderRadius: 8, fontSize: 13 }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: '#4f46e5', color: '#fff', fontSize: 11, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{i + 1}</div>
            {step}
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 380, margin: '0 auto' }}>
        {isSales ? (
          <>
            <button style={{ ...btn.submit, ...btn.amber }}><i className="ti ti-headset" /> Talk to sales</button>
            <button style={btn.secondary}><i className="ti ti-layout-dashboard" /> Go to dashboard</button>
          </>
        ) : (
          <>
            <button style={btn.submit}><i className="ti ti-rocket" /> Go to dashboard</button>
            <button style={btn.secondary}><i className="ti ti-book" /> View documentation</button>
          </>
        )}
      </div>
    </div>
  )
}

// ─── Sidebar content per step ────────────────────────────────────────────────

function SidebarContent({ step, cardprogram, outcome }) {
  if (step <= 1) return <SidebarCard title="Interested in Issuing APIs?" body="Create and manage cards programmatically." link="Get started" />
  if (step >= 3 && step <= 4) return <SidebarCard title="Supported use cases" body="Learn about the use cases Issuing supports and how to set up your program." link="View documentation" />
  if (step === 5) return (
    <>
      <SidebarCard title="Compare card programs" body="Compare features, pricing, and API access across all three options." link="View comparison" />
      {cardprogram === 'custom' && <SidebarCard title="Talk to sales" body="The custom solution requires a tailored commercial arrangement. Our team will walk you through the options." link="Contact sales" />}
    </>
  )
  if (step === 6) return <SidebarCard title="Your card is confirmed" body={outcome ? `You've selected the ${outcome.cardName}. Complete the remaining steps to activate your program.` : 'Complete the remaining steps to activate your card program.'} />
  if (step === 7) return (
    <>
      <SidebarCard title="Why do we need this?" body="KYB is a regulatory requirement for all card programs. Your data is encrypted and never shared without consent." />
      <SidebarCard title="Why prefill?" body="If your business is already verified on Stripe, we can pull your details automatically." />
    </>
  )
  if (step === 8) return <SidebarCard title="Almost there" body="Review your selections carefully. You can go back to any step to make changes before submitting." />
  if (step === 9) {
    if (!outcome) return null
    const isSales = outcome.type === 'sales', isTrial = outcome.type === 'trial'
    return <SidebarCard
      title={isSales ? 'Sales will be in touch' : isTrial ? 'Trial is active' : 'Program is live'}
      body={isSales ? 'A Stripe solutions engineer will contact you within 1 business day.' : isTrial ? 'Live mode trial is active. Data carries over when you go live.' : 'Your card program is active. Issue your first card from the dashboard.'}
    />
  }
  return null
}

// ─── Root App ────────────────────────────────────────────────────────────────

const INITIAL_KYB = { bizname: '', regno: '', country: '', address: '', biztype: '', ein: '', fname: '', lname: '', dob: '', pct: '', title: '' }

export default function App() {
  const [step, setStep] = useState(0)
  const [cardtype, setCardtype] = useState('')
  const [currency, setCurrency] = useState('')
  const [audience, setAudience] = useState('')
  const [usecase, setUsecase] = useState('')
  const [desc, setDesc] = useState('')
  const [cardprogram, setCardprogram] = useState('')
  const [kyb, setKyb] = useState(INITIAL_KYB)
  const [prefilled, setPrefilled] = useState(false)
  const [prefilling, setPrefilling] = useState(false)

  const outcome = audience && cardprogram ? OUTCOME_MATRIX[audience]?.[cardprogram] || null : null
  const bizName = (kyb.bizname || 'YOUR BUSINESS').toUpperCase()

  const handleKybChange = (id, val) => setKyb(prev => ({ ...prev, [id]: val }))

  const handlePrefill = () => {
    setPrefilling(true)
    setTimeout(() => {
      setKyb(MOCK_STRIPE_ACCOUNT)
      setPrefilled(true)
      setPrefilling(false)
    }, 1400)
  }

  const handleClearPrefill = () => {
    setKyb(INITIAL_KYB)
    setPrefilled(false)
  }

  const handleAudienceChange = (val) => {
    setAudience(val)
    setUsecase('')
  }

  const goTo = (n) => setStep(n)

  const stepComponents = [
    <StepWelcome onNext={() => goTo(1)} />,
    <StepCardType value={cardtype} onChange={setCardtype} onNext={() => goTo(2)} onBack={() => goTo(0)} />,
    <StepCurrency value={currency} onChange={setCurrency} onNext={() => goTo(3)} onBack={() => goTo(1)} />,
    <StepCardholder value={audience} onChange={handleAudienceChange} onNext={() => goTo(4)} onBack={() => goTo(2)} />,
    <StepUseCase audience={audience} usecase={usecase} onUsecase={setUsecase} desc={desc} onDesc={setDesc} onNext={() => goTo(5)} onBack={() => goTo(3)} />,
    <StepCardProgram value={cardprogram} onChange={setCardprogram} onNext={() => goTo(6)} onBack={() => goTo(4)} />,
    <StepYourCard outcome={outcome} bizName={bizName} onNext={() => goTo(7)} onBack={() => goTo(5)} />,
    <StepKYB fields={kyb} onChange={handleKybChange} prefilled={prefilled} onPrefill={handlePrefill} onClearPrefill={handleClearPrefill} prefilling={prefilling} onNext={() => goTo(8)} onBack={() => goTo(6)} />,
    <StepReview selections={{ cardtype, currency, audience, usecase, desc, cardprogram }} outcome={outcome} prefilled={prefilled} onSubmit={() => goTo(9)} onBack={() => goTo(7)} />,
    <StepCongrats outcome={outcome} />,
  ]

  return (
    <div style={{ fontFamily: 'var(--font-sans)', background: '#f7f7f8', minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 24px', background: '#fff', borderBottom: '0.5px solid #f3f4f6' }}>
        <div style={{ fontSize: 14, fontWeight: 500 }}>Set up Issuing</div>
        <div style={{ display: 'flex', gap: 8 }}>
          {['Need help?', 'Save and exit'].map(label => (
            <button key={label} style={{ fontSize: 12, padding: '6px 14px', borderRadius: 8, border: '0.5px solid #e5e7eb', background: '#fff', cursor: 'pointer', color: '#6b7280', fontFamily: 'inherit' }}>{label}</button>
          ))}
        </div>
      </div>

      {/* Body */}
      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr 240px', flex: 1, minHeight: 0 }}>
        {/* Stepper */}
        <Stepper current={step} total={STEPS.length} labels={STEPS} />

        {/* Main content */}
        <div style={{ padding: '32px 36px', overflow: 'auto', background: '#fff' }}>
          {stepComponents[step]}
        </div>

        {/* Sidebar */}
        <div style={{ padding: '24px 20px', background: '#f7f7f8', borderLeft: '0.5px solid #f3f4f6' }}>
          <SidebarContent step={step} cardprogram={cardprogram} outcome={outcome} />
        </div>
      </div>
    </div>
  )
}
