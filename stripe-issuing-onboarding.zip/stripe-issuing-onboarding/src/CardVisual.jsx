import React from 'react'

const LINK_MARK = (
  <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: 11, height: 11 }}>
    <path d="M2.5 2L6.5 5.5L2.5 9" stroke="#0a2e1a" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M5.5 5.5L7.5 3.5" stroke="#0a2e1a" strokeWidth="2.2" strokeLinecap="round" />
  </svg>
)

function buildWavePaths() {
  const lines = []
  const w = 380, h = 220
  for (let i = 0; i < 38; i++) {
    const y = i * (h / 36)
    const amp = 14 + Math.sin(i * 0.4) * 6
    const freq = 0.022 + Math.sin(i * 0.15) * 0.006
    let d = `M 0 ${y}`
    for (let x = 0; x <= w; x += 4) {
      const wy = y + Math.sin(x * freq + i * 0.45) * amp
      d += ` L ${x} ${wy}`
    }
    lines.push(<path key={i} d={d} stroke="rgba(255,255,255,0.09)" strokeWidth="0.8" fill="none" />)
  }
  return lines
}

const s = {
  card: {
    width: '100%', maxWidth: 380, height: 220, borderRadius: 18,
    margin: '0 auto 28px', position: 'relative', overflow: 'hidden',
    display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
    padding: '22px 24px', boxShadow: '0 20px 60px rgba(0,0,0,0.22)',
  },
  shine: {
    position: 'absolute', top: '-40%', left: '-20%', width: '60%', height: '180%',
    background: 'linear-gradient(105deg,transparent 40%,rgba(255,255,255,0.07) 50%,transparent 60%)',
    pointerEvents: 'none',
  },
  chip: { width: 32, height: 24, borderRadius: 4, marginBottom: 14, background: 'linear-gradient(135deg,#f0c040,#d4a820)' },
  num: { fontSize: 13, color: 'rgba(255,255,255,0.85)', letterSpacing: 3, marginBottom: 6, fontFamily: 'monospace' },
  name: { fontSize: 11, color: 'rgba(255,255,255,0.65)', textTransform: 'uppercase', letterSpacing: '0.08em' },
  logo: { fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.9)', letterSpacing: '0.04em', position: 'relative', zIndex: 1 },
}

export default function CardVisual({ cardClass, cardName, bizName = 'YOUR BUSINESS' }) {
  if (cardClass === 'stripe-card') {
    return (
      <div style={{ ...s.card, background: 'linear-gradient(130deg,#9b8de8 0%,#7c5fe8 30%,#6344d4 55%,#7b50d4 75%,#9568e0 100%)' }}>
        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }} viewBox="0 0 380 220" preserveAspectRatio="none">
          {buildWavePaths()}
        </svg>
        {/* chip top-right */}
        <div style={{ position: 'absolute', top: 22, right: 24, width: 36, height: 26, background: 'rgba(255,255,255,0.18)', border: '0.5px solid rgba(255,255,255,0.25)', borderRadius: 4, zIndex: 2 }} />
        <div style={s.logo}>Stripe</div>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={s.num}>•••• •••• •••• 4242</div>
          <div style={s.name}>{bizName}</div>
        </div>
        {/* bottom-right: business + mastercard */}
        <div style={{ position: 'absolute', bottom: 20, right: 20, zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5 }}>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', fontWeight: 500 }}>business</div>
          <div style={{ display: 'flex' }}>
            <div style={{ width: 26, height: 26, borderRadius: '50%', background: '#c0392b', opacity: 0.9, marginRight: -8 }} />
            <div style={{ width: 26, height: 26, borderRadius: '50%', background: '#b8860b', opacity: 0.85 }} />
          </div>
          <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.7)', letterSpacing: '0.06em' }}>mastercard</div>
        </div>
      </div>
    )
  }

  if (cardClass === 'link-card') {
    return (
      <div style={{ ...s.card, background: '#0a2e1a' }}>
        <div style={s.shine} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, position: 'relative', zIndex: 1 }}>
          <div style={{ width: 22, height: 22, borderRadius: '50%', background: '#00d25b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{LINK_MARK}</div>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#fff', letterSpacing: '-0.02em' }}>link</div>
        </div>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ ...s.chip, background: 'linear-gradient(135deg,#00d25b,#00a847)' }} />
          <div style={s.num}>•••• •••• •••• 4242</div>
          <div style={s.name}>{bizName}</div>
        </div>
        <div style={{ position: 'absolute', bottom: 20, right: 20, display: 'flex', alignItems: 'center', gap: 5, zIndex: 2 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#00d25b' }} />
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)', letterSpacing: '0.05em' }}>LINK CARD</div>
        </div>
      </div>
    )
  }

  if (cardClass === 'link-premium-card') {
    return (
      <div style={{ ...s.card, background: '#0a2e1a' }}>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: 'linear-gradient(90deg,#f0c040,#d4a820,#f0c040)' }} />
        <div style={s.shine} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, position: 'relative', zIndex: 1 }}>
          <div style={{ width: 22, height: 22, borderRadius: '50%', background: '#00d25b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{LINK_MARK}</div>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#fff', letterSpacing: '-0.02em' }}>link</div>
          <span style={{ fontSize: 10, fontWeight: 600, color: '#f0c040', letterSpacing: '0.08em', marginLeft: 2 }}>PREMIUM</span>
        </div>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ ...s.chip, background: 'linear-gradient(135deg,#f0c040,#d4a820)' }} />
          <div style={s.num}>•••• •••• •••• 4242</div>
          <div style={s.name}>{bizName}</div>
        </div>
        <div style={{ position: 'absolute', bottom: 20, right: 20, display: 'flex', alignItems: 'center', gap: 5, zIndex: 2 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#f0c040' }} />
          <div style={{ fontSize: 10, color: '#f0c040', letterSpacing: '0.05em' }}>LINK PREMIUM</div>
        </div>
      </div>
    )
  }

  if (cardClass === 'premium-card') {
    return (
      <div style={{ ...s.card, background: 'linear-gradient(135deg,#1a1a2e,#16213e,#0f3460)' }}>
        <div style={s.shine} />
        <div style={s.logo}>{cardName}</div>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={s.chip} />
          <div style={s.num}>•••• •••• •••• 4242</div>
          <div style={s.name}>{bizName}</div>
        </div>
        <div style={{ position: 'absolute', bottom: 20, right: 20, display: 'flex', zIndex: 2 }}>
          <div style={{ width: 24, height: 24, borderRadius: '50%', background: '#c0392b', opacity: 0.8, marginRight: -8 }} />
          <div style={{ width: 24, height: 24, borderRadius: '50%', background: '#b8860b', opacity: 0.8 }} />
        </div>
      </div>
    )
  }

  // sales-card / default
  return (
    <div style={{ ...s.card, background: 'linear-gradient(135deg,#78350f,#92400e)' }}>
      <div style={s.shine} />
      <div style={s.logo}>{cardName}</div>
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={s.chip} />
        <div style={s.num}>•••• •••• •••• 4242</div>
        <div style={s.name}>{bizName}</div>
      </div>
    </div>
  )
}
