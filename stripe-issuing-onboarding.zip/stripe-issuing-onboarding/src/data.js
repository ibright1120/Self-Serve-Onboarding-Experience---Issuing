export const USE_CASE_MAP = {
  company: [
    { val: 'corporate', title: 'Corporate expense', desc: "Let employees or contractors make purchases on your business' behalf." },
    { val: 'reseller', title: 'Reseller', desc: 'Buy goods or services for inventory to resell to your customers.' },
    { val: 'ondemand', title: 'On-demand services', desc: "Buy goods and services from merchants on your customers' behalf." },
    { val: 'fleet', title: 'Fleet', desc: 'Manage fuel and vehicle-related expenses across your fleet.' },
    { val: 'bnpl', title: 'BNPL', desc: 'Buy now, pay later programs for your customers.' },
  ],
  businesses: [
    { val: 'corporate', title: 'Corporate expense management', desc: "Let employees or contractors make purchases on your business' behalf." },
    { val: 'fleet', title: 'Fleet', desc: 'Manage fuel and vehicle-related expenses across your fleet.' },
    { val: 'insurance', title: 'Insurance', desc: 'Issue cards to pay out insurance claims or manage policyholder expenses.' },
  ],
  consumers: [
    { val: 'consumer-expenses', title: 'Consumer expenses', desc: 'Issue cards for everyday consumer spending and expense tracking.' },
    { val: 'payout', title: 'Payout', desc: 'Instantly pay out funds to consumers via a dedicated card.' },
  ],
}

export const AUDIENCE_NAMES = {
  company: 'My company',
  businesses: 'Businesses on my platform',
  consumers: 'Consumers on my platform',
}

export const CARD_TYPE_NAMES = { prefunded: 'Prefunded card', charge: 'Charge', credit: 'Credit' }
export const CURRENCY_NAMES = { local: 'Local currency', usdc: 'USDC' }
export const PROGRAM_NAMES = { 'stripe-branded': 'Stripe branded', 'co-branded': 'Co-branded', custom: 'Custom solution' }

export const OUTCOME_MATRIX = {
  company: {
    'stripe-branded': { type: 'production', cardName: 'Stripe Card', cardClass: 'stripe-card', headline: 'Your card is the Stripe Card', sub: 'No-code, instant production access. Issue cards to your team today.', perks: [{ icon: 'ti-bolt', t: 'Instant activation', d: 'Live in production immediately' }, { icon: 'ti-layout-dashboard', t: 'No-code dashboard', d: 'Manage everything in the UI' }, { icon: 'ti-credit-card', t: 'Free issuance', d: 'No per-card fees' }, { icon: 'ti-shield-check', t: 'Fraud controls', d: 'Built-in spend controls' }], congrats: 'Your Stripe Card program is live.', nextSteps: ['Issue your first card from the dashboard', 'Set spend limits for cardholders', 'Invite your team'] },
    'co-branded': { type: 'production', cardName: 'Stripe Premium Card', cardClass: 'premium-card', headline: 'Your card is the Stripe Premium Card', sub: 'Co-branded, instant production access with rev share based on spend volume.', perks: [{ icon: 'ti-medal', t: 'Co-branded', d: 'Your brand on the card' }, { icon: 'ti-trending-up', t: 'Rev share', d: 'Earn on spend volume' }, { icon: 'ti-code', t: 'Issuing APIs', d: 'Full API access' }, { icon: 'ti-receipt-2', t: 'Activity pricing', d: 'Pay as you go' }], congrats: 'Your Stripe Premium Card program is live.', nextSteps: ['Configure your co-branding', 'Set up rev share settings', 'Issue your first card'] },
    custom: { type: 'sales', cardName: 'Custom Card', cardClass: 'sales-card', headline: "You're getting a Custom Card", sub: 'Our sales team will finalise your custom commercial arrangement.', perks: [{ icon: 'ti-paint', t: 'Custom branding', d: 'Your own card design' }, { icon: 'ti-code', t: 'Full API access', d: 'Complete Issuing API suite' }, { icon: 'ti-trending-up', t: 'Rev share + custom terms', d: 'Tailored arrangement' }, { icon: 'ti-sparkles', t: 'And more…', d: 'Discuss options with sales' }], congrats: 'Your application is with the sales team.', nextSteps: ['Watch for an email from your solutions engineer', 'Prepare your use case details', 'Review custom term options'] },
  },
  businesses: {
    'stripe-branded': { type: 'production', cardName: 'Stripe Card', cardClass: 'stripe-card', headline: 'Offer the Stripe Card to your businesses', sub: 'Instant production access. Your platform businesses can start spending right away.', perks: [{ icon: 'ti-users', t: 'Platform-ready', d: 'Issue to businesses on your platform' }, { icon: 'ti-bolt', t: 'Instant production', d: 'Live access from day one' }, { icon: 'ti-credit-card', t: 'Free issuance', d: 'No per-card fees' }, { icon: 'ti-shield-check', t: 'Spend controls', d: 'Set limits per business' }], congrats: 'The Stripe Card is ready for your businesses.', nextSteps: ['Onboard your first business', 'Issue cards on their behalf', 'Configure platform settings'] },
    'co-branded': { type: 'production', cardName: 'Stripe Premium Card', cardClass: 'premium-card', headline: 'Offer the Stripe Premium Card to your businesses', sub: 'Instant production access, API access, and rev share based on spend volume.', perks: [{ icon: 'ti-medal', t: 'Co-branded', d: 'Your brand front and centre' }, { icon: 'ti-trending-up', t: 'Rev share', d: 'Earn on spend volume' }, { icon: 'ti-code', t: 'Issuing APIs', d: 'Full API access' }, { icon: 'ti-receipt-2', t: 'Activity pricing', d: 'Pay as you go' }], congrats: 'The Stripe Premium Card is ready for your businesses.', nextSteps: ['Configure co-branding', 'Onboard your first business', 'Set rev share preferences'] },
    custom: { type: 'trial', cardName: 'Custom Card', cardClass: 'sales-card', headline: 'Start with a live mode trial', sub: 'Instant live mode trial while our sales team works out your custom arrangement.', perks: [{ icon: 'ti-flask', t: 'Live mode trial', d: 'Real transactions right away' }, { icon: 'ti-paint', t: 'Custom branding', d: 'Your own card design' }, { icon: 'ti-trending-up', t: 'Rev share + custom terms', d: 'Tailored arrangement' }, { icon: 'ti-sparkles', t: 'And more…', d: 'Discuss with your solutions engineer' }], congrats: 'Your live mode trial is active.', nextSteps: ['Start transacting in live mode trial', 'Watch for your solutions engineer', 'Trial data carries to production'] },
  },
  consumers: {
    'stripe-branded': { type: 'production', cardName: 'Link Card', cardClass: 'link-card', headline: 'Offer the Link Card to your consumers', sub: 'Instant production access. Seamless card payments powered by Stripe Link.', perks: [{ icon: 'ti-link', t: 'Powered by Link', d: 'Seamless consumer experience' }, { icon: 'ti-bolt', t: 'Instant production', d: 'Live from day one' }, { icon: 'ti-credit-card', t: 'Free issuance', d: 'No per-card fees' }, { icon: 'ti-shield-check', t: 'Consumer controls', d: 'Per-cardholder spend limits' }], congrats: 'The Link Card is ready for your consumers.', nextSteps: ['Issue Link Cards to your consumers', 'Configure spending controls', 'Set up transaction notifications'] },
    'co-branded': { type: 'production', cardName: 'Link Premium Card', cardClass: 'link-premium-card', headline: 'Offer the Link Premium Card to your consumers', sub: 'Instant production access with API access and rev share based on spend volume.', perks: [{ icon: 'ti-medal', t: 'Co-branded', d: 'Your brand on every card' }, { icon: 'ti-trending-up', t: 'Rev share', d: 'Earn on consumer spend volume' }, { icon: 'ti-code', t: 'Issuing APIs', d: 'Full API access' }, { icon: 'ti-receipt-2', t: 'Activity pricing', d: 'Pay as you go' }], congrats: 'The Link Premium Card is ready for your consumers.', nextSteps: ['Configure co-branding', 'Issue cards to consumers', 'Set rev share preferences'] },
    custom: { type: 'trial', cardName: 'Custom Card', cardClass: 'sales-card', headline: 'Start with a live mode trial', sub: "Instant live mode trial access while our sales team finalises your custom arrangement.", perks: [{ icon: 'ti-flask', t: 'Live mode trial', d: 'Real transactions right away' }, { icon: 'ti-paint', t: 'Custom branding', d: 'Your own card design' }, { icon: 'ti-trending-up', t: 'Rev share + custom terms', d: 'Tailored commercial arrangement' }, { icon: 'ti-sparkles', t: 'And more…', d: 'Discuss with your solutions engineer' }], congrats: 'Your live mode trial is active.', nextSteps: ['Start transacting in live mode trial', 'Watch for your solutions engineer', 'Trial data carries to production'] },
  },
}

export const MOCK_STRIPE_ACCOUNT = {
  bizname: 'Galtee Insurance Ltd.',
  regno: 'IE-4821093',
  country: 'Ireland',
  address: '12 Merrion Square, Dublin 2, D02 XY12',
  biztype: 'Corporation',
  ein: '98-1234567',
  fname: 'Conor',
  lname: 'Murphy',
  dob: '04 / 15 / 1981',
  pct: '51%',
  title: 'CEO',
}

export const STEPS = [
  'Get started',
  'Card type',
  'Currency',
  'Cardholder',
  'Use case',
  'Card program',
  'Your card',
  'Business verification',
  'Review & submit',
]
