# Stripe Issuing Onboarding Prototype

A fully interactive onboarding flow for Stripe Issuing card programs.

## Deploy to Vercel

### Option 1 — Vercel CLI (fastest)
```bash
npm install -g vercel
cd stripe-issuing-onboarding
npm install
vercel
```

### Option 2 — GitHub + Vercel Dashboard
1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import the repo
4. Vercel auto-detects Vite — just click Deploy

### Option 3 — Drag & drop
1. Run `npm install && npm run build` locally
2. Drag the `dist/` folder to [vercel.com/new](https://vercel.com/new)

## Local development
```bash
npm install
npm run dev
```

## Environment variables
The LLM-powered silent evaluation on the Use Case step calls the Anthropic API.
To enable it in production, add your API key as an environment variable in Vercel:

```
VITE_ANTHROPIC_API_KEY=sk-ant-...
```

Then update the fetch call in `src/App.jsx` (StepUseCase) to use:
```js
headers: { 'Content-Type': 'application/json', 'x-api-key': import.meta.env.VITE_ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' }
```

> **Note:** For production use, proxy the API call through a server-side function to keep your API key secure.

## What's included
- 10-step onboarding flow (Welcome → Card type → Currency → Cardholder → Use case → Card program → Your card → Business verification → Review → Congratulations)
- Conditional use cases based on cardholder selection
- Silent LLM evaluation of program description
- Card visual previews (Stripe Card with wavy lines, Link Card, Link Premium Card, Premium Card, Custom/Sales Card)
- KYB prefill from Stripe account
- Full outcome routing matrix (9 outcomes across 3 cardholder × 3 program combinations)
- Congratulations screen with next steps
